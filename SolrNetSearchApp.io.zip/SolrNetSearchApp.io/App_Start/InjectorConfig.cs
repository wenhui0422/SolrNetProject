﻿/* 
 *      Name:           InjectorConfig 
 *      Description:    This class is used for registering SolrNet
 *      Author:         Wenhui Fan
 *      Created:        2019/02/13
 *      Last Updated:   2019/02/14
 */

using SolrNet;
using SolrNet.Impl;
using SolrNetSearchApp.io.Models;
using SolrNetSearchApp.io.Models.Binders;
using SolrNetSearchApp.io.Services;
using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.Mvc;

namespace SolrNetSearchApp.io
{
    public class InjectorConfig
    {
        public static void RegisterSolr(string solrURL)
        {
            var connection = new SolrConnection(solrURL)
            {
                HttpWebRequestFactory = new DemoHttpWebRequestFactory()
            };

            var loggingConnection = new LoggingConnection(connection);
            Startup.Init<Product>(loggingConnection);

            // Registers controllers in the DI container
            var controllers = typeof(MvcApplication).Assembly.GetTypes().Where(t => typeof(IController).IsAssignableFrom(t));
            foreach (var controller in controllers)
            {
                Type controllerType = controller;
                Startup.Container.Register(GetControllerName(controller), controller, c => GetContainerRegistration(c, controllerType));
            }

            ControllerBuilder.Current.SetControllerFactory(new ServiceProviderControllerFactory(Startup.Container));

            ModelBinders.Binders[typeof(SearchParameters)] = new SearchParametersBinder();
        }

        /// <summary>
        /// Gets a controller instance with its dependencies injected.
        /// Picks the first constructor on the controller.
        /// </summary>
        /// <param name="container"></param>
        /// <param name="t">Controller type</param>
        /// <returns></returns>
        private static IController GetContainerRegistration(IServiceProvider container, Type t)
        {
            var constructor = t.GetConstructors()[0];
            var dependencies = constructor.GetParameters().Select(p => container.GetService(p.ParameterType)).ToArray();
            return (IController)constructor.Invoke(dependencies);
        }

        private static string GetControllerName(Type t)
        {
            return Regex.Replace(t.Name, "controller$", "", RegexOptions.IgnoreCase);
        }

    }
}