﻿/* 
 *      Name:           ProductView 
 *      Description:    This class is used for display product info on front-end
 *      Author:         Wenhui Fan
 *      Created:        2019/02/13
 *      Last Updated:   2019/02/16
 */

using System.Collections.Generic;

namespace SolrNetSearchApp.io.Models
{
    public class ProductView {
        public SearchParameters Search { get; set; }
        public ICollection<Product> Products { get; set; }
        public int TotalCount { get; set; }
        public IDictionary<string, ICollection<KeyValuePair<string, int>>> Facets { get; set; }
        public string DidYouMean { get; set; }
        public bool QueryError { get; set; }
        public int QueryTime { get; set; }
        public List<List<string>> KeywordsRelated { get; set; }

        public ProductView() {
            Search = new SearchParameters();
            Facets = new Dictionary<string, ICollection<KeyValuePair<string, int>>>();
            Products = new List<Product>();
        }
    }
}