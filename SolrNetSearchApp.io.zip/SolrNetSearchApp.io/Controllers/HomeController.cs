﻿/* 
 *      Name:           HomeController 
 *      Author:         Wenhui Fan
 *      Created:        2019/02/13
 *      Last Updated:   2019/02/15
 */

using SolrNet;
using SolrNet.Exceptions;
using SolrNetSearchApp.io.Models;
using SolrNetSearchApp.io.Services;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace SolrNetSearchApp.io.Controllers
{
    public class HomeController : Controller
    {
        private readonly ISolrReadOnlyOperations<Product> solr;

        public HomeController(ISolrReadOnlyOperations<Product> solr)
        {
            this.solr = solr;
        }

        public ActionResult Index(SearchParameters parameters)
        {
            try
            {
                var matchingProducts = DataManager.SearchSpellChecking(parameters);
                var view = new ProductView
                {
                    Products = matchingProducts,
                    Search = parameters,
                    TotalCount = matchingProducts.NumFound,
                    QueryTime = matchingProducts.Header.QTime,
                    Facets = matchingProducts.FacetFields,
                    DidYouMean = DataManager.GetSpellCheckingResult(matchingProducts),
                    KeywordsRelated = DataManager.GetKeywordsRelatedResult(matchingProducts, parameters)
                };

                return View(view);
            }
            catch (SolrNetException e)
            {
                return View(new ProductView
                {
                    QueryError = true,
                });
            }
        }

        [HttpGet]
        public JsonResult GetProducts()
        {
            var searchResult = solr.Query(SolrQuery.All).Select(x => new { Name = x.Name.FirstOrDefault() });

            var lst = new List<string> { "engineer", "engineering", "engineers", "engineered" };
            foreach(var s in searchResult)
            {
                var str = s.Name.Split(' ');
                if (!lst.Contains(str[0])) lst.Add(str[0]);
            }

            return Json(new { data = lst }, JsonRequestBehavior.AllowGet);
            //try
            //{
            //    var matchingProducts = DataManager.SearchSpellChecking(parameters);
            //    var view = new ProductView
            //    {
            //        Products = matchingProducts,
            //        Search = parameters,
            //        TotalCount = matchingProducts.NumFound,
            //        QueryTime = matchingProducts.Header.QTime,
            //        Facets = matchingProducts.FacetFields,
            //        DidYouMean = DataManager.GetSpellCheckingResult(matchingProducts),
            //    };

            //    return Json(view);
            //}
            //catch (SolrNetException e)
            //{
            //    return Json(new ProductView
            //    {
            //        QueryError = true,
            //    });
            //}
        }


    }

}