/* 
 *      Name:           LoggingConnection 
 *      Description:    This class is used for logging data process info
 *      Author:         Wenhui Fan
 *      Created:        2019/02/13
 *      Last Updated:   2019/02/14
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using log4net;
using SolrNet;

namespace SolrNetSearchApp.io.Services
{
    public class LoggingConnection: ISolrConnection {
        
        private static readonly ILog logger = LogManager.GetLogger(typeof(LoggingConnection));
        private readonly ISolrConnection connection;

        public LoggingConnection(ISolrConnection connection) {
            this.connection = connection;
        }

        public string Post(string relativeUrl, string s) {
            logger.DebugFormat("Posting '{0}' to '{1}'", s, relativeUrl);
            return connection.Post(relativeUrl, s);
        }

        public string PostStream(string relativeUrl, string contentType, Stream content, IEnumerable<KeyValuePair<string, string>> getParameters) {
            logger.DebugFormat("Posting to '{0}'", relativeUrl);
            return connection.PostStream(relativeUrl, contentType, content, getParameters);
        }

        public string Get(string relativeUrl, IEnumerable<KeyValuePair<string, string>> parameters) {
            var stringParams = string.Join(", ", parameters.Select(p => string.Format("{0}={1}", p.Key, p.Value)).ToArray());
            logger.DebugFormat("Getting '{0}' from '{1}'", stringParams, relativeUrl);
            return connection.Get(relativeUrl, parameters);
        }

        public Task<string> PostAsync(string relativeUrl, string s)
        {
            logger.DebugFormat("Posting '{0}' to '{1}'", s, relativeUrl);
            return Task.FromResult(connection.Post(relativeUrl, s));
        }

        public Task<string> PostStreamAsync(string relativeUrl, string contentType, Stream content, IEnumerable<KeyValuePair<string, string>> getParameters)
        {
            throw new NotImplementedException();
        }

        public Task<string> GetAsync(string relativeUrl, IEnumerable<KeyValuePair<string, string>> parameters, CancellationToken cancellationToken = default(CancellationToken))
        {
            throw new NotImplementedException();
        }
    }
}