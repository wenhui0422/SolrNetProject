﻿/* 
 *      Name:           DataManager 
 *      Description:    This class is used for data processing
 *      Author:         Wenhui Fan
 *      Created:        2019/02/13
 *      Last Updated:   2019/02/16
 */

using CommonServiceLocator;
using SolrNet;
using SolrNet.Commands.Parameters;
using SolrNet.DSL;
using SolrNet.Exceptions;
using SolrNetSearchApp.io.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace SolrNetSearchApp.io.Services
{
    public static class DataManager
    {
        /// <summary>
        /// All selectable facet fields
        /// </summary>
        public static readonly string[] AllFacetFields = new[] { "cat", "manu" };

        public static void DataInitialization(string solrURL)
        {
            try
            {
                var solr = ServiceLocator.Current.GetInstance<ISolrOperations<Product>>();
                solr.Delete(SolrQuery.All);
                var connection = ServiceLocator.Current.GetInstance<ISolrConnection>();
                foreach (var file in Directory.GetFiles(HttpContext.Current.Server.MapPath("~/App_Data/sampledata"), "*.xml"))
                {
                    connection.Post("/update", File.ReadAllText(file, Encoding.UTF8));
                }
                solr.Commit();

                solr.BuildSpellCheckDictionary();            
            }
            catch (SolrConnectionException e)
            {
                throw new Exception(string.Format("Couldn't connect to Solr that is running on '{0}'.", solrURL), e);
            }
        }

        public static ISolrQuery BuildQuery(SearchParameters parameters)
        {
            if (!string.IsNullOrEmpty(parameters.FreeSearch))
                return new SolrQuery(string.Format("{0}:{1}", "name", parameters.FreeSearch)); 
            return SolrQuery.All;
        }

        public static ICollection<ISolrQuery> BuildFilterQueries(SearchParameters parameters)
        {
            var queriesFromFacets = from p in parameters.Facets
                                    select (ISolrQuery)Query.Field(p.Key).Is(p.Value);
            return queriesFromFacets.ToList();
        }

        /// <summary>
        /// Gets the selected facet fields
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public static IEnumerable<string> SelectedFacetFields(SearchParameters parameters)
        {
            return parameters.Facets.Select(f => f.Key);
        }

        public static SortOrder[] GetSelectedSort(SearchParameters parameters)
        {
            return new[] { SortOrder.Parse(parameters.Sort) }.Where(o => o != null).ToArray();
        }

        public static string GetSpellCheckingResult(SolrQueryResults<Product> products)
        {
            return string.Join(" ", products.SpellChecking
                                        .Select(c => c.Suggestions.FirstOrDefault())
                                        .Where(c => !string.IsNullOrEmpty(c))
                                        .ToArray());
        }

        public static List<List<string>> GetKeywordsRelatedResult(SolrQueryResults<Product> products, SearchParameters parameters)
        {
            var lst = products.Select(c => new { Title = c.Name.FirstOrDefault(), SearchKey = parameters.FreeSearch })
                             .Where(y => !string.IsNullOrEmpty(y.Title) 
                                         && !string.IsNullOrEmpty(y.SearchKey) 
                                         && y.SearchKey.Contains(parameters.FreeSearch));

            var relatedLst = new List<List<string>>();
            foreach (var e in lst)
            {
                var words = e.Title.Split(new char[] {' ', ',', '\\', '\n'}, StringSplitOptions.RemoveEmptyEntries);
                //int idx = Array.IndexOf(words, e.SearchKey);
                int idx = Array.FindIndex(words, item => item.ToUpper() == e.SearchKey.ToUpper());

                if (idx > 0)
                {
                    int len = words.Length - 1;
                    var singleLst = new List<string>();

                    if (len > 2)
                    {
                        if (idx == 0)
                        {
                            var arr = new List<string>();
                            arr.Add(words[0]);
                            if (!(words[1].Equals("-") || words[1].Equals("&")))
                            {
                                arr.Add(words[1]);
                            }

                            if (arr.Count > 1)
                            {
                                singleLst.Add(string.Join(" ", arr));
                            }
                        }
                        else if (idx == len)
                        {
                            var arr = new List<string>();
                            if (!(words[len - 1].Equals("-") || words[len - 1].Equals("&")))
                            {
                                arr.Add(words[len - 1]);
                            }

                            arr.Add(words[idx]);

                            if (arr.Count > 1)
                            {
                                singleLst.Add(string.Join(" ", arr));
                            }
                        }
                        else
                        {
                            var arr = new List<string>();
                            if (!(words[idx - 1].Equals("-") || words[idx - 1].Equals("&")))
                            {
                                arr.Add(words[idx - 1]);
                            }

                            arr.Add(words[idx]);

                            if (!words[idx + 1].Equals("-"))
                            {
                                arr.Add(words[idx + 1]);
                            }

                            if (arr.Count > 1)
                            {
                                singleLst.Add(string.Join(" ", arr));
                            }
                        }
                    }
                    else if (len == 2)
                    {
                        if (idx == 0)
                        {
                            var arr = new List<string>();
                            arr.Add(words[0]);
                            if (!(words[1].Equals("-") || words[1].Equals("&")))
                            {
                                arr.Add(words[1]);
                            }

                            if (arr.Count > 1)
                            {
                                singleLst.Add(string.Join(" ", arr));
                            }
                        }
                        else if (idx == len)
                        {
                            var arr = new List<string>();
                            if (!(words[len - 1].Equals("-") || words[len - 1].Equals("&")))
                            {
                                arr.Add(words[len - 1]);
                            }

                            arr.Add(words[idx]);

                            if (arr.Count > 1)
                            {
                                singleLst.Add(string.Join(" ", arr));
                            }
                        }
                    }

                    bool flag = IsElementInList(relatedLst, singleLst);
                    if (!flag)
                    {
                        relatedLst.Add(singleLst);
                    }
                }               
            }

            return relatedLst;
        }

        private static bool IsElementInList(List<List<string>> list, List<string> arr)
        {
            return list.Select(ar2 => arr.All(ar2.Contains)).FirstOrDefault();
        }

        public static SolrQueryResults<Product> SearchSpellChecking(SearchParameters parameters)
        {
            var solr = ServiceLocator.Current.GetInstance<ISolrOperations<Product>>();

            var start = (parameters.PageIndex - 1) * parameters.PageSize;

            var options = new QueryOptions
            {
                FilterQueries = BuildFilterQueries(parameters),
                //Rows = parameters.PageSize,
                StartOrCursor = new StartOrCursor.Start(start),
                OrderBy = GetSelectedSort(parameters),
                SpellCheck = new SpellCheckingParameters() { Collate = true, Dictionary = "iPod iPad", Query = parameters.FreeSearch },
                Facet = new FacetParameters
                {
                    Queries = AllFacetFields.Except(SelectedFacetFields(parameters))
                                                                          .Select(f => new SolrFacetFieldQuery(f) { MinCount = 1 })
                                                                          .Cast<ISolrFacetQuery>()
                                                                          .ToList(),
                }
            };

            var searchResult = solr.Query(BuildQuery(parameters), options);

            return searchResult;
        }

    }
  

}