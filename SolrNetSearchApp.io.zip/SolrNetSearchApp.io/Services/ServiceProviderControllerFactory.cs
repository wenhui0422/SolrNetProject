﻿/* 
 *      Name:           ServiceProviderControllerFactory 
 *      Description:    This class is used for injecting SolrNet service provider
 *      Author:         Wenhui Fan
 *      Created:        2019/02/13
 *      Last Updated:   2019/02/14
 */

using HttpWebAdapters;
using HttpWebAdapters.Adapters;
using System;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace SolrNetSearchApp.io.Services
{ 
    public class ServiceProviderControllerFactory : DefaultControllerFactory {

        private readonly IServiceProvider container;

        public ServiceProviderControllerFactory(IServiceProvider container) {
            this.container = container;
        }

        protected override IController GetControllerInstance(RequestContext context, Type controllerType) {

            if (controllerType == null) {
                throw new HttpException(404, string.Format("The controller for path '{0}' could not be found or it does not implement IController.", context.HttpContext.Request.Path));
            }

            return (IController) container.GetService(controllerType);
        }

        public override void ReleaseController(IController controller)
        {
            var disposable = controller as IDisposable;

            if (disposable != null)
            {
                disposable.Dispose();
            }
        }
    }

    class DemoHttpWebRequestFactory : IHttpWebRequestFactory
    {
        public IHttpWebRequest Create(Uri url)
        {
            HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(url);
            CredentialCache wrCache = new CredentialCache();
            wrCache.Add(url, "Basic", new NetworkCredential("user", "12345"));
            webrequest.Credentials = wrCache;
            return new HttpWebRequestAdapter((HttpWebRequest)webrequest);
        }
    }
}