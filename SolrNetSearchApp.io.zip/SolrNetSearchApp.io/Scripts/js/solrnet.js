﻿/* 
 *      Name:           solrnet.js
 *      Author:         Wenhui Fan
 *      Created:        2019/02/13
 *      Last Updated:   2019/02/15
 */

$(function () {
    
    $.ajax({
        method: "GET",
        url: "Home/GetProducts",
        success: function (result) {
            if (!result.hasOwnProperty("errorNo")) {
                if (result.data !== null) {
                    $('#q').typeahead({
                        source: result.data
                    });
                }
            }
        },
        error: function (response) {
        },
        async: false
    });
       
    $("#q").focusout(function () {
        location.href = "/?q=" + $(this).val();
    });
});
